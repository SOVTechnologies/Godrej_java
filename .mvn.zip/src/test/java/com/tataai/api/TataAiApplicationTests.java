package com.tataai.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TataAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
