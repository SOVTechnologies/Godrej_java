package com.tataai.api.utils;

public class Utililty {
    private Utililty() {
    }

}
