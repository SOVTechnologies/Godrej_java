package com.tataai.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GodrejAPIApplication {

	public static void main(String[] args) {
		SpringApplication.run(GodrejAPIApplication.class, args);
	}

}
