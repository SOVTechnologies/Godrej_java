package com.tataai.api.controller;

import com.tataai.api.model.SourceType;
import com.tataai.api.repository.SourceTypeRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class SourceTypeController {

    private final SourceTypeRepository sourceTypeRepository;

    @GetMapping(value = "/sourcetypes", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<SourceType> findAllSourceType() {
        return this.sourceTypeRepository.findAll();
    }

    @PostMapping(value = "/addSourceType", produces = MediaType.APPLICATION_JSON_VALUE)
    public SourceType addSourceType(@RequestBody SourceType sourceType) {
        return this.sourceTypeRepository.save(sourceType);
    }
}
