package com.tataai.api.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

 
import com.tataai.api.model.WorldRegoin; 
import com.tataai.api.repository.WorldRegionRepository;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/region")
@RequiredArgsConstructor
public class WorldRegionController {

    private final WorldRegionRepository regionRepository;

    @GetMapping(value = "/country", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<WorldRegoin> findAllCountry() {
        return regionRepository.findAll();
    }


    @GetMapping(value = "/state/{countryName}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<WorldRegoin> findAllState(@PathVariable String countryName) {
        return regionRepository.findByCountry(countryName);
    }


    @GetMapping(value = "/city/{stateName}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<WorldRegoin> findAllCity(@PathVariable String stateName) {
        return regionRepository.findByState(stateName);
    }
}
