package com.tataai.api.controller;

import com.tataai.api.model.Customer;
import com.tataai.api.repository.CustomerRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class CustomerController {

    private final CustomerRepository customerRepository;

    

    @GetMapping(value = "/customers",produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<Customer> findAllCustomer() {
        return this.customerRepository.findAll();
    }

    @PostMapping(value = "/addCustomer",produces = MediaType.APPLICATION_JSON_VALUE)
    public Customer addCustomer(@RequestBody Customer customer) {
        return this.customerRepository.save(customer);
    }
}
