package com.tataai.api.controller;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.tataai.api.model.GetMobileAndOtp;
import com.tataai.api.model.GetMobileNumber;
import com.tataai.api.model.Otp;
import com.tataai.api.repository.OtpRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Random;

@RestController
@RequiredArgsConstructor
public class OtpController {

    private final OtpRepository otpRepository;

    @PostMapping("/isOTPValid")
    public String isOTPValid(@RequestBody GetMobileAndOtp otp) {

        List<Otp> result = otpRepository.findByMobilenoAndOtp(otp.getMobileno(), otp.getOtp());

        return result.size() > 0 ? "Found" : "Not Found";
    }

    @GetMapping(value = "/otpList", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<Otp> findAll() {
        return this.otpRepository.findAll();
    }

    @PostMapping(value = "/sendOtp", produces = MediaType.TEXT_PLAIN_VALUE)
    public String add(@RequestBody GetMobileNumber otp) throws UnirestException {
        String otpNumber = String.format("%04d", new Random().nextInt(10000));
        String number = "91" + otp.getNumber();
        Unirest.setTimeouts(0, 0);
        HttpResponse<String> response = Unirest.post("https://2factor.in/API/R1/").field("module", "TRANS_SMS")
                .field("apikey", "a0b64286-2d78-11ee-addf-0200cd936042").field("to", number).field("from", "SOVTE")
                .field("msg", "Hi Your One Time Mobile Phone\n" + "Verification Code is " + otpNumber).asString();
        System.out.println(response.toString());
        Otp saveOtpRow = new Otp();
        saveOtpRow.setMobileno(otp.getNumber());
        saveOtpRow.setOtp(otpNumber);
        this.otpRepository.save(saveOtpRow);

        return "Success";
    }
}
