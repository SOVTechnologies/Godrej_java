package com.tataai.api.repository;

import com.tataai.api.model.Otp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OtpRepository extends JpaRepository<Otp, Long> {
    //@Query("SELECT count(*) FROM trans_otp WHERE mobileno = ?1 AND otp = ?2")
    List<Otp> findByMobilenoAndOtp(String mobileno,String otp);
}
