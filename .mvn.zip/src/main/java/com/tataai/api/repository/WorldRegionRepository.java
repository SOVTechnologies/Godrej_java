package com.tataai.api.repository;
 
import com.tataai.api.model.WorldRegoin;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WorldRegionRepository extends CrudRepository<WorldRegoin, Long> {

    List<WorldRegoin> findByState(String stateName);
    List<WorldRegoin> findByCountry(String countryName);

}
