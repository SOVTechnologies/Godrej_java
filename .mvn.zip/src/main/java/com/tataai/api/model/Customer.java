package com.tataai.api.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@Table(name = "trans_customer")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long customerid;
    private String customeruniqueno;
    private String mobile;
    private String customerfirstname;
    private String customerlastname;
    private String typologypreference;
    private String emailid;
    private Integer sourcetype;
    private String source_name;
    private String address;
    private String pan;
    private String panimage;
    private String paymentconfirmation;
    private Long paymenttranscationno;
    private Integer amount;
    private String cp_email;
    private String cp_empanelmentnumber;
    private String createdby;
    private String createdon;
    private String updatedby;
    private String updatedon;
}
