package com.tataai.api.model;

import lombok.Data; 

@Data
public class GetMobileNumber {
    private  String number;
}
