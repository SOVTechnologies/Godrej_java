package com.tataai.api.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@Table(name = "country")
public class WorldRegoin {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer Id;
    private String country;
    private int population;
    private String state;
    private String capital;
    private String currency;
    private String city;
    
}
